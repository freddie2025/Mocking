﻿namespace ConsoleUI
{
    public interface IApplication
    {
        void Run();
    }
}